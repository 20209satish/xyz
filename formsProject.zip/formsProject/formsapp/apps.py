from django.apps import AppConfig


class FormsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'formsapp'
