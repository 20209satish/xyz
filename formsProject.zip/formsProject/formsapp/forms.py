from sitesapp.models import *
from django import forms

class SitesForm(forms.ModelForm):
    class Meta:
        model = Sites
        exclude = ['fields']

class FieldForm(forms.ModelForm):
    pass
        