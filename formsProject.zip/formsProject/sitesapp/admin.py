from django.contrib import admin
from.models import User, Event, Person, Project, Question, Answers, Effort


# Register your models here.
admin.site.register(Event)
admin.site.register(Person)
admin.site.register(Project)
admin.site.register(Question)
admin.site.register(Answers)
admin.site.register(Effort)




