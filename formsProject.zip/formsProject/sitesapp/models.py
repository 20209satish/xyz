from django.db import models
from django.contrib.auth.models import AbstractUser
from formsapp.models import User

# Create your models here.


class Day(models.Model):
    day = models.CharField(max_length=50, null=True, blank=True)

class Effort(models.Model):
    effort = models.CharField(max_length=100, null=True, blank=True)
    description = models.CharField(max_length=1000, blank=True, null=True) 

class Image(models.Model):
    images = models.ImageField(upload_to='images/', null=True, blank=True)
    person_images = models.ImageField(upload_to='person_images/', null=True, blank=True)


class Person(models.Model):
    image = models.ImageField(upload_to='person/', blank=True, null=True)
    name = models.CharField(max_length=50, null=True, blank=True)
    about_the_person = models.CharField(max_length=250, null=True, blank=True)    
        
class Event(models.Model):
    code = models.CharField(max_length=30, null=True, blank=True)
    authenticated_responder = models.BooleanField(default=False)
    name = models.CharField(max_length=50, null=True, blank=True)
    s_name = models.CharField(max_length=50, null=True, blank=True)
    event_name = models.CharField(max_length=50, null=True, blank=True)
    event_date = models.CharField(max_length=500, null=True, blank=True)
    from_time_date = models.DateField(auto_now_add=False, null=True, blank=True)
    to_time_date = models.TimeField(auto_now_add=False, null=True, blank=True)
    venue = models.CharField(max_length=150, null=True, blank=True)
    summit_d1_d2_d3 = models.CharField(max_length=50, null=True, blank=True)
    persons = models.ManyToManyField(Person, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    days = models.ManyToManyField(Day, blank=True)
    address = models.CharField(max_length=50, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)


class Question(models.Model):
    question = models.CharField(max_length=200, null=True, blank=True)

class Answers(models.Model):
    answer = models.CharField(max_length=1000, null=True, blank=True)            

class Project(models.Model):
    code = models.CharField(max_length=30, null=True, blank=True)
    title = models.CharField(max_length=50, null=True, blank=True)
    name = models.CharField(max_length=50, null=True, blank=True)
    authenticated_responder = models.BooleanField(default=False)
    s_name = models.CharField(max_length=50, null=True, blank=True)
    page_title = models.CharField(max_length=1000, null=True, blank=True)
    description = models.CharField(max_length=1000, null=True, blank=True)
    mission = models.CharField(max_length=500, null=True, blank=True)
    m_description = models.CharField(max_length=1000, null=True, blank=True)
    bg_image = models.ImageField(upload_to='bg_images/', default='bg_image.jpg', null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user')
    questions = models.ManyToManyField(Question, blank=True)
    answers = models.ManyToManyField(Answers, blank=True)
    email = models.EmailField(max_length=100, null=True, blank=True)
    link = models.URLField(null=True, blank=True)
    address = models.TextField(max_length=300, null=True, blank=True)
    phone_number = models.IntegerField(null=True, blank=True)
    members = models.ManyToManyField(Person,blank=True)
    efforts = models.ManyToManyField(Effort, related_name='Efforts', blank=True)
    icon = models.ImageField(upload_to='favicon/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)    
    updated_at = models.DateTimeField(auto_now=True)


class Portfolio(models.Model):
    code = models.CharField(max_length=30, null=True, blank=True)
    authenticated_responder = models.BooleanField(default=False)
    s_name = models.CharField(max_length=50, null=True, blank=True)
    title = models.CharField(max_length=30, null=True, blank=True)
    name = models.CharField(max_length=50, null=True, blank=True)
    role = models.CharField(max_length=50, null=True, blank=True)
    location = models.CharField(max_length=50, null=True, blank=True)
    selected_work = models.CharField(max_length=50, null=True, blank=True)
    name_of_project = models.CharField(max_length=50, null=True, blank=True)
    name_of_presentation = models.CharField(max_length=150, null=True, blank=True)
    name_of_video = models.CharField(max_length=100, null=True, blank=True)
    get_in_touch = models.EmailField(max_length=50, null=True, blank=True) 
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)




# class Step(models.Model):
#     step = models.CharField(max_length=200, null=True, blank=True)
#     steps_to = models.ForeignKey(Section, on_delete=models.CASCADE, null=True, blank=True) 

class Help_center(models.Model):
    s_name = models.CharField(max_length=50, null=True, blank=True)
    authenticated_responder = models.BooleanField(default=False)
    title = models.CharField(max_length=50, null=True, blank=True)
    question = models.CharField(max_length=100, null=True, blank=True)
    code = models.CharField(max_length=30, null=True, blank=True)
    live_chat=models.CharField(max_length=500, null=True, blank=True)
    mobile_number = models.IntegerField(null=True, blank=True)
    email=models.EmailField(max_length=50, null=True, blank=True)
    brief = models.CharField(max_length=100, blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)
    topic_1 = models.CharField(max_length=200, null=True, blank=True)
    topic_2 = models.CharField(max_length=200, null=True, blank=True)
    topic_3 = models.CharField(max_length=200, null=True, blank=True)
    topic_4 = models.CharField(max_length=200, null=True, blank=True)
    section_1 = models.CharField(max_length=200, null=True, blank=True)
    section_2 = models.CharField(max_length=200, null=True, blank=True)
    section_3 = models.CharField(max_length=200, null=True, blank=True)
    section_4 = models.CharField(max_length=200, null=True, blank=True)

class Fields(models.Model):
    text = models.CharField(max_length=5000, null=True, blank=True)
    img = models.ImageField(upload_to='field_images/', null=True, blank=True)
    urls = models.CharField(max_length=10000, blank=True, null=True)    

class BlankSite(models.Model):
    code = models.CharField(max_length=30, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    authenticated_responder = models.BooleanField(default=False)
    s_name = models.CharField(max_length=50, null=True, blank=True)
    title = models.CharField(max_length=100, null=True, blank=True)
    name = models.CharField(max_length=500, null=True, blank=True)
    description = models.CharField(max_length=5000, null=True, blank=True)
    text_fields = models.ManyToManyField(Fields, blank=True, related_name='text_fields')
    img_fields = models.ManyToManyField(Fields, blank=True, related_name='img_fields')
    url_fields = models.ManyToManyField(Fields, blank=True, related_name='url_fields')





class Sites(models.Model):
    SITES = (
        (0, 'Event'),
        (1, 'Help_center'),
        (2, 'Portfolio'),
        (3, 'Project')
    )
    site_name = models.IntegerField(default=0, choices=SITES)
    fields = models.CharField(max_length=5000, null=True, blank=True)
    











