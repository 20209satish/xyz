from rest_framework import serializers
from .models import Event, Person, Project, Question, Answers, Effort

class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = '__all__'

class PersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = '__all__'

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = '__all__'

class AnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Answers
        fields = '__all__'

class EffortSerializer(serializers.ModelSerializer):
    class Meta:
        model = Effort
        fields = '__all__'


