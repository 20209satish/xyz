from rest_framework import routers
from .views import *

router = routers.DefaultRouter()
router.register(r'Event', EventViewSet)
router.register(r'Person', PersonViewSet)
# router.register(r'Template', TemplateViewSet)
router.register(r'Question', QuestionViewset)
router.register(r'Answer', AnswerViewset)
router.register(r'Effort', EffortViewset)

urlpatterns = router.urls