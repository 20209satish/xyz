from django.shortcuts import render
from .models import *
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import *
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    

class PersonViewSet(viewsets.ModelViewSet):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer
    

# class TemplateViewSet(viewsets.ModelViewSet):
#     queryset = Site.objects.all()
#     serializer_class = TemplateSerializer
    
class QuestionViewset(viewsets.ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer 
    
class AnswerViewset(viewsets.ModelViewSet):
    queryset = Answers.objects.all()
    serializer_class = AnswerSerializer


class EffortViewset(viewsets.ModelViewSet):
    queryset = Effort.objects.all()
    serializer_class = EffortSerializer
            
