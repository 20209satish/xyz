document.addEventListener("DOMContentLoaded", () => {
    document.querySelector("#nav-ham").addEventListener("click", () => {
        document.querySelector("#sidebar").style.width = "250px";
    })
    document.querySelector("#close-sidebar").addEventListener('click', () => {
        document.querySelector("#sidebar").style.width = "0px";
    })
    document.querySelector("#create-blank-form").addEventListener("click", () => {
        const csrf = Cookies.get('csrftoken');
        fetch('/site/create', {
            method: "POST",
            headers: {'X-CSRFToken': csrf},
            body: JSON.stringify({
                title: "Untitled Site"
            })
        })
        .then(response => response.json())
        .then(result => {
            window.location = `/site/${result.code}/edit`
        })
    })
    document.querySelector("#create-project-site").addEventListener("click", () => {
        const csrf = Cookies.get('csrftoken');
        fetch('/site/create/project_site', {
            method: "POST",
            headers: {'X-CSRFToken': csrf},
            body: JSON.stringify({})
        })
        .then(response => response.json())
        .then(result => {
            window.location = `/site/${result.code}/edit_project`
        })
    })
    document.querySelector("#create-portfolio-site").addEventListener("click", () => {
        const csrf = Cookies.get('csrftoken');
        fetch('/site/create/portfolio_site', {
            method: "POST",
            headers: {'X-CSRFToken': csrf},
            body: JSON.stringify({})
        })
        .then(response => response.json())
        .then(result => {
            window.location = `/site/${result.code}/edit_portfolio`
        })
    })
    document.querySelector("#create-help-center-site").addEventListener("click", () => {
        const csrf = Cookies.get('csrftoken');
        fetch('/site/create/help_center', {
            method: "POST",
            headers: {'X-CSRFToken': csrf},
            body: JSON.stringify({})
        })
        .then(response => response.json())
        .then(result => {
        window.location = `/site/${result.code}/edit_help_center`
        })
    })
    document.querySelector("#create-event-site").addEventListener("click",()=>{
        const csrf = Cookies.get('csrftoken');
        fetch('/site/create/event_site', {
            method: "POST",
            headers: {'X-CSRFToken': csrf},
            body: JSON.stringify({})
        })
        .then(response => response.json())
        .then(result => {
            window.location = `/site/${result.code}/edit_event_site`
        })
    })
})